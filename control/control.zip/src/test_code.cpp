// #include "l298n.h"
// #include "Config.h"
// // #include

// L298N l298n[]{L298N(enable_pin_1, input1_1, input2_1),
//               L298N(enable_pin_2, input1_2, input2_2)};
// void setup(){
//     l298n[0].driver_init();
//     l298n[1].driver_init();
// }

// void loop(){
//     l298n[0].set_speed(255);
//     l298n[1].set_speed(255);
//     l298n[0].set_direction(255);
//     l298n[1].set_direction(255);

//     l298n[0].control_speed();
//     l298n[1].control_speed();
// }