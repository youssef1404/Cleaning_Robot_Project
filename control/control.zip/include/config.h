#ifndef CONFIG_H
#define CONFIG_H

#define MOTOR_IN1 12
#define MOTOR_IN2 13
#define MOTOR_IN3 14
#define MOTOR_IN4 15
#define MOTOR_ENA 16
#define MOTOR_ENB 17

#define RIGHT_MOTOR_ENCA 18
#define RIGHT_MOTOR_ENCB 19

#define SERVO_PIN 15
#define UPPER_LIMIT 180
#define LOWER_LIMIT 0

#define ULTRA1_TRIGGER_PIN 18
#define ULTRA1_ECHO_PIN 19
#define ULTRA2_TRIGGER_PIN 20
#define ULTRA2_ECHO_PIN 21

#define MAX_SPEED 255
#define MIN_SPEED 0
#define DEFAULT_SPEED 50

// Wi-Fi credentials
#define WIFI_SSID "Honor 50"       
#define WIFI_PASSWORD "12345678" 
#define AGENT_IP "192.168.153.203"           
#define AGENT_PORT 8888 

#define LED_PIN LED_BUILTIN

#endif